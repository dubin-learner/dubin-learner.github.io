#include <QtWidgets/QWidget>
class Widget : public QWidget {
  Q_OBJECT
  public:
    Widget(QWidget * parent = NULL) : QWidget(parent) {}
};
